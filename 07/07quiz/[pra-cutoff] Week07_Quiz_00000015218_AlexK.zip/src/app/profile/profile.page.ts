import { Component, OnInit } from '@angular/core';
import { UKM } from '../home/UKM';
import { UkmServService } from '../home/ukm-serv.service';
import { IonItemSliding } from '@ionic/angular';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {
  
  constructor(private ukmServ: UkmServService) { }

  ngOnInit() {
  }

  unjoinUKM(ukmId: string, slidingItem: IonItemSliding)
  {
    slidingItem.close();
  }
}
