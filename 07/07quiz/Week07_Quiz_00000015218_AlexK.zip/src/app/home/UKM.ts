export interface UKM {
  id: string;
  name: string;
  imageURL: string;
  desc: string;
}
