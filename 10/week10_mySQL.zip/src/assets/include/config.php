<?php
    $hostname = "localhost";
    $username = "mobj5177_admin";
    $pswd = "adminLab507";
    $dbname = "mobj5177_fti_booking_db";
?>